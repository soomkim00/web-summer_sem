function show() {
    var str = '';
    str = exform06.txt_name.value + '님은\n';
    str = str + exform06.r_pr.value + '을(를)\n';
    str = str + '좋아하십니다.'
    alert(str);
}