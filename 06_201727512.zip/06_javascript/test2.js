function show() {
    var str = '';
    str = test2.txt.value + '님 안녕하세요!';
    document.getElementById('msg').innerHTML=str;
}